<!DOCTYPE>


<!---sujon   --->
<html>
	<head>
		<title>Online Shop</title>
		<link rel="stylesheet" href="styles/style.css" media="all" />
		
	</head>
</html>

<body>

	<!--Main Container starts here -->
	<div class="main_wrapper">
	
	
	<!--Header starts here -->
		<div class="header_wrapper">
			
			<img id="logo" src="images/logo.jpg"/>
			<img id="banner" src="images/ad_banner.jpg"/>
		</div>
		
		
	<!--Header ends here -->
	
	
	<!--_______________________Navigation Bar starts       here -->
		
			<div class="menubar">
				
				<ul id="menu">
					<li><a href="">Home</a></li>
					<li><a href="">All Products</a></li>
					<li><a href="">My Account</a></li>
					<li><a href="">Sign Up</a></li>
					<li><a href="">Shopping cart</a></li>
					<li><a href="">Contact Us</a></li>
				
				</ul>	
				
				<div id="form">
					<form method="get" action="results.php" enctype="multipart/form-data">
					<input type="submit" name="search" value="Search"></input>
					</form>
				
				</div>
			
			</div>
			
	
	<!--_______________________Navigation Ends here -->		
		

		<div class="content_wrapper">
		
		    <div id="sidebar">ajsfadkjfakfjadkfhakdhfkadhfkad</div>
			 
			<div id="content_area">This is content area</div>			
		
		</div>
		

		
		<div id="footer">This is footer</div>
		
		<!--Main Container ends here -->
		
		
	
	
	
	
	
	</div>



</body>

