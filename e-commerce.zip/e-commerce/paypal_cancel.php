<?php

session_start();

?>
<html>
	<head>
		<title>Payment Cancel!</title>
	</head>
	
	<body>
	
	<h2>Payment was cancelled!</h2>
	<h3>Your payment was not successful, please go back our shop and try again. </h3>
	
	
	</body>
	
</html>
		