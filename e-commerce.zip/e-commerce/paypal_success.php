<?php

session_start();

?>
<html>
	<head>
		<title>Payment Successful!</title>
	</head>
	
	<body>
	
	<h2>Welcome <?php echo $_SESSION['customer_email']; ?></h2>
	<h3>Your payment was successful, please go to your account </h3>
	
	
	</body>
	
</html>
		